package com.example.mysubmission2.ui.main

import androidx.lifecycle.*
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.example.mysubmission2.data.local.response.Story
import com.example.mysubmission2.paging.StoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class MainVIewModel @Inject constructor(repository: StoryRepository) : ViewModel(){
    val isLoading: LiveData<Boolean> = repository.isLoading
    val story: LiveData<PagingData<Story>> = repository.getStory().cachedIn(viewModelScope)
}