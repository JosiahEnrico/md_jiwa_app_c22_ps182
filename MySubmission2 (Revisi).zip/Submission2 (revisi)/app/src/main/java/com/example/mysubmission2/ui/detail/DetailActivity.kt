package com.example.mysubmission2.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.mysubmission2.R
import com.example.mysubmission2.data.local.response.Story
import com.example.mysubmission2.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    private val binding by lazy(LazyThreadSafetyMode.NONE) {
        ActivityDetailBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        supportActionBar?.title = getString(R.string.detail_title)
        setDetail()

        val actionBar = supportActionBar
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    private fun setDetail() {
        intent.apply {
            val name = getStringExtra(STORY_NAME)
            val description = getStringExtra(EXTRA_DESCRIPTION)
            val image = getStringExtra(EXTRA_IMAGE)

            binding.apply {
                tvItemName.text = name
                tvItemDescription.text = description
                Glide.with(this@DetailActivity)
                    .load(image)
                    .into(imItemPhoto)
            }
        }
    }

    companion object{
        const val EXTRA_IMAGE = "extra_image"
        const val STORY_NAME = "story_name"
        const val EXTRA_DESCRIPTION = "extra_description"
    }

}