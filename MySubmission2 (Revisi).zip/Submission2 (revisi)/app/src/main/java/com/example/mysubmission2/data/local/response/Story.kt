package com.example.mysubmission2.data.local.response

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Entity
@Parcelize
data class Story(
    val createdAt: String,
    val description: String,
    @PrimaryKey
    val id: String,
    val name: String,
    val photoUrl: String,
    val lat: Double,
    val lon: Double
) :  Parcelable