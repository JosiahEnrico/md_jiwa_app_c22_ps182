package com.example.mysubmission2.data.local.response

data class StoriesResponse(
    val error: Boolean,
    val listStory: List<Story>,
    val message: String
)