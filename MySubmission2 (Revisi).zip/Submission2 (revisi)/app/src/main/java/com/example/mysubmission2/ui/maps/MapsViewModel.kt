package com.example.mysubmission2.ui.maps

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.mysubmission2.data.local.response.Story
import com.example.mysubmission2.paging.StoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class MapsViewModel @Inject constructor(private val repository: StoryRepository) : ViewModel() {

    val listStory: LiveData<List<Story>> = repository.listStory
    fun getAllStoryWithMaps(token: String) {
        repository.getStoryWithLocation("Bearer $token")
    }
}