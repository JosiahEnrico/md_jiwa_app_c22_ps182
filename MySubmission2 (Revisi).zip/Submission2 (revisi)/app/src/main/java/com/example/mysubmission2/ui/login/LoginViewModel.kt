package com.example.mysubmission2.ui.login

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.mysubmission2.data.local.response.LoginResult
import com.example.mysubmission2.paging.StoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(private val repository: StoryRepository) : ViewModel() {

    val userLogin: LiveData<LoginResult> = repository.userLogin
    val toastMessage: LiveData<String> = repository.toastMessage
    val isLoading: LiveData<Boolean> = repository.isLoading
    fun loginUser(email: String, password: String) = repository.loginUser(email, password)

}