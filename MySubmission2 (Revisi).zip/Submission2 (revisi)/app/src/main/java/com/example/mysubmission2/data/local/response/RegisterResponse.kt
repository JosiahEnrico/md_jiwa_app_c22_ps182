package com.example.mysubmission2.data.local.response

data class RegisterResponse(
    val error: Boolean,
    val message: String
)