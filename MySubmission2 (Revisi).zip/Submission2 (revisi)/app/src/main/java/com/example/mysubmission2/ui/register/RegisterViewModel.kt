package com.example.mysubmission2.ui.register

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.mysubmission2.paging.StoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class RegisterViewModel @Inject constructor(private val repository: StoryRepository) : ViewModel() {

    val isLoading: LiveData<Boolean> = repository.isLoading
    fun registerUser(name: String, email: String,password: String) {
        repository.registerUser(name, email, password)
    }

}