package com.example.mysubmission2.data.local.response

data class AddResponse(
    val error: Boolean,
    val message: String
)