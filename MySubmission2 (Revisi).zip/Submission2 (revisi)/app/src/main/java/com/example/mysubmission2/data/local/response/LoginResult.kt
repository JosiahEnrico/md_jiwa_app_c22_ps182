package com.example.mysubmission2.data.local.response

data class LoginResult(
    var name: String,
    var token: String,
    var userId: String
)