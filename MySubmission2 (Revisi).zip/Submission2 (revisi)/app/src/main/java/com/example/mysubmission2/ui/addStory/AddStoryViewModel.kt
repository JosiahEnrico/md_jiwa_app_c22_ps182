package com.example.mysubmission2.ui.addStory

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.mysubmission2.paging.StoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import okhttp3.RequestBody
import java.io.File
import javax.inject.Inject

@HiltViewModel
class AddStoryViewModel @Inject constructor(private val repository: StoryRepository): ViewModel() {
    val toastMessage: LiveData<String> = repository.toastMessage
    fun postStoryWithLocation(token: String, imageMultipart: File, description: String, latitude: RequestBody? = null, longitude: RequestBody? = null) {
        repository.postStoryWithLocation(token, imageMultipart, description, latitude, longitude)
    }



}