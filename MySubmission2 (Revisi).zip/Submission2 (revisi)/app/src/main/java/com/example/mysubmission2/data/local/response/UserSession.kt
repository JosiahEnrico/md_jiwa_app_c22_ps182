package com.example.mysubmission2.data.local.response

data class UserSession(
    val name: String,
    val token: String,
    val userId: String,
    val isLogin: Boolean
)